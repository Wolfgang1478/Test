package sorting;


import java.util.Random;
import java.util.Scanner;

public class SortingAlgorithms {

	private static Random r;
	private static int[] numbers;
	private static Scanner scan;

	public static void main(String[] args) {
		menu();
	}

	public static void createVector(){
		numbers = new int[r.nextInt(100)];
		for (int i = 0; i < numbers.length; i++) 
			numbers[i] = r.nextInt(1000);
	}

	public static int[] bubbleSort(int[] a){
		int aux = 0;
		for (int i = 0; i < a.length - 1; i++) 
			for (int j = 0; j < a.length - 1; j++) {
				if (a[j] > a[j + 1]) {
					aux = a[j];
					a[j] = a[j + 1];
					a[j + 1] = aux;
				}
			}

		return a;
	}

	private static String print(int[] a){
		String print = "";
		for (int i = 0; i < a.length; i++)
			if(i != a.length - 1)
				print += a[i] +", ";
			else
				print += a[i]+" ";
		return print;
	}

	private static int[] selectionSort(int[] a){
		int aux = 0, menor = 0;
		for (int i = 0; i < a.length - 1; i++) {
			menor = i;
			for (int j = i + 1; j < a.length; j++) 
				if(a[j] < a[menor])
					menor = j;
			if(menor != i){	
				aux = a[i];
				a[i] = a[menor];
				a[menor] = aux;

			}
		}
		return a;
	}

	private static int[] insertionSort(int[] a){
		int j = 0, aux = 0;
		for (int i = 0; i < a.length - 1; i++) {
			j = i + 1;
			while (j > 0 && a[j - 1] > a[j]) {
				aux = a[j - 1];
				a[j - 1] = a[j];
				a[j] = aux;
				j--;
			}
		}
		return a;
	}

	private static boolean verifySorting(int[] a){
		boolean truth = true;
		for (int i = 0; i < a.length - 1; i++) {
			if(a[i+1]  < a[i])
				truth = false;
		}
		return truth;
	}

	private static void menu(){
		r = new Random();
		scan = new Scanner(System.in);
		int option = 0;
		while(option != 7){
			System.out.println("Please select an option:\n\n1. Create a random array\n2. Sort array with bubble sort"
					+"\n3. Sort array with insertion sort\n4. Sort array with selection sort\n5. Verify sorting\n6. Print array\n7. Exit");
			option = Integer.parseInt(scan.nextLine());
			try{
				switch (option) {

				case 1:
					createVector();
					System.out.println("Vector successfully created\n");
					break;
				case 2:
					bubbleSort(numbers);
					break;
				case 3:
					insertionSort(numbers);
					break;
				case 4:
					selectionSort(numbers);
					break;
				case 5:
					if(verifySorting(numbers))
						System.out.println("Array successfully sorted, data is organized in ascending order");
					else
						System.out.println("The array is currently unsorted");
					break;
				case 6:
					System.out.println(print(numbers));
					break;
				case 7:
					System.out.println("Terminating program please wait...");
					System.exit(0);
					break;
				default:
					System.out.println("Error, invalid input");
					break;
				}
			}catch(NullPointerException e){
				System.out.println("Array not currently filled with anything, please select option 1 to continue");
			}
		}
	}

}
