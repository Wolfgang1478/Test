package mundo;

import java.util.ArrayList;
import javax.swing.JOptionPane;


@SuppressWarnings({ "unused", "rawtypes" })
public class Operaciones {


	private static String primero, segundo;

	/**
	 * Se ejecuta el programa
	 * @param args
	 */
	public static void main(String[] args) {
		primero = "";
		segundo = "";
		ArrayList<Integer> primerNum, segundoNum;
		primerNum = new ArrayList<Integer>();
		segundoNum = new ArrayList<Integer>();
		//		imprimir(sumar(ingresar(primerNum), ingresar(segundoNum)));
		//		imprimir(restar(ingresar(primerNum), ingresar(segundoNum)));
		//		imprimir(multiplicacionSimple(ingresar(primerNum), Integer.parseInt(JOptionPane.showInputDialog(null, "Ingrese las veces que desea multiplicar el n�mero"))));
		//		inicializarTablaDeMultiplicacion();
		//		imprimir(multiplicacion(ingresar(primerNum), ingresar(segundoNum)));
		//		imprimir(sumaIterativa(ingresar(primerNum), ingresar(segundoNum)));
		//		System.out.println(restaIterativa(Integer.parseInt(JOptionPane.showInputDialog(null, "Ingrese el primer numero")), Integer.parseInt(JOptionPane.showInputDialog(null, "Ingrese el segundo numero"))));
		//		System.out.println(multiplicacionRusse(Integer.parseInt(JOptionPane.showInputDialog(null, "Ingrese el primer n�mero")), Integer.parseInt(JOptionPane.showInputDialog(null, "Ingrese el segundo n�mero"))));
		System.out.println(multiplicacionEgipcia(Integer.parseInt(JOptionPane.showInputDialog(null, "Ingrese el primer numero")), Integer.parseInt(JOptionPane.showInputDialog(null, "Ingrese el segundo numero"))));
	}

	/**
	 * 
	 * @param a
	 * @param b
	 * @return
	 */
	public static boolean iguales(ArrayList<Integer> a, ArrayList<Integer> b){

		int menor = Math.min(a.size(), b.size());
		for(int i = 0; i< menor; i++)
			if(a.get(i) != b.get(i))
				return false;
		if(a.size() > menor)
			for(int i = menor; i < a.size(); i++)
				if(a.get(i) != 0)
					return false;
		if(b.size() > menor)
			for(int i = menor; i < b.size(); i++)
				if(b.get(i) != 0)
					return false;		
		return true;
	}
	/**
	 * 
	 * @param numero
	 * @param veces
	 * @return
	 */
	public static ArrayList<Integer> sumaIterativa(ArrayList<Integer> numero, ArrayList<Integer> veces){

		ArrayList<Integer> resultado = new ArrayList<Integer>(), i = new ArrayList<Integer>(), uno = new ArrayList<Integer>(), aux = new ArrayList<Integer>();
		uno.add(1);
		aux.add(0);
		for( i.add(0) ; i.get(0) < veces.get(0); i =sumar(i, uno)){
			resultado = sumar(numero, aux);
			aux = resultado;
		}				
		return resultado;
	}

	/**
	 * 
	 * @param one
	 * @return
	 */
	public static ArrayList<Integer> toArray(Integer one){
		ArrayList<Integer> aux = new ArrayList<Integer>();
		String two = one+"";
		for (int i = two.length() - 1; i >= 0; i--) {
			aux.add(Integer.parseInt(two.charAt(i)+""));
		}

		return aux;
	}

	public static int multiplicacionRusse(int primero, int segundo){
		int resultado = 0, contador = 0, impar = 0;
		ArrayList<Integer> primeroL = new ArrayList<Integer>(), segundoL = new ArrayList<Integer>();
		primeroL.add(primero); segundoL.add(segundo);
		int i = 0;
		while(segundoL.get(i) > 0){
			primeroL.add(primeroL.get(i) * 2);
			if(segundoL.get(i) % 2 != 0){
				segundoL.add((segundoL.get(i) - 1) / 2);
				contador += primeroL.get(i);
				impar++;
			}else
				segundoL.add(segundoL.get(i) / 2);
			i++;
		}
		if(impar != 0)
			resultado = contador;
		else
			resultado = primeroL.get(primeroL.size() - 1);
		return resultado;
	}

	public static int multiplicacionEgipcia(int primero, int segundo){
		int i = 0, aux = 0, temp = 0;
		ArrayList<Integer> primeroL = new ArrayList<Integer>(), segundoL = new ArrayList<Integer>();
		primeroL.add(primero);
		segundoL.add(1);
		while((segundoL.get(i) * 2) < segundo){
			primeroL.add(primeroL.get(i) * 2);
			segundoL.add(segundoL.get(i) * 2);
			i++;
		}
		imprimir(primeroL);
		imprimir(segundoL);
		for (int j = segundoL.size() - 1; j >= 0; j--) {
			if(j == segundoL.size() - 1)
				aux = segundoL.get(segundoL.size() - 1);
			else{
				if(aux + segundoL.get(j) <= segundo){
					aux += segundoL.get(j);
					temp += primeroL.get(j);
				}
			}
		}
		temp += primeroL.get(primeroL.size() - 1);
		return temp;
	}

	public static int restaIterativa(int primero, int segundo){
		int resultado = primero, i = -1;
		while(resultado >= 0){
			resultado -= segundo;
			i++;
		}
		resultado = i;
		return resultado;
	}

	/**
	 * 
	 * @param numero
	 * @return
	 */
	public static String toString(ArrayList<Integer> numero){
		String msg = "";
		for (int i = numero.size() - 1; i >= 0; i--) {
			msg += numero.get(i);
		}
		return msg;
	}
	/**
	 * 
	 * @param factor
	 * @param veces
	 * @return
	 */
	public static ArrayList<Integer> multiplicacion(ArrayList<Integer> factor, ArrayList<Integer> veces){
		ArrayList<Integer> resultado = new ArrayList<Integer>(), i = new ArrayList<Integer>(), j = new ArrayList<Integer>(), uno = new ArrayList<Integer>(), k = new ArrayList<Integer>(),
				aux = new ArrayList<Integer>(), aux3 = new ArrayList<Integer>();
		int acarreo = 0;
		uno.add(1);
		aux.add(0);
		for(i.add(0); i.get(0) != Integer.parseInt(toString(veces)); i = sumar(i, uno)){
			for(k.add(0); k.get(0) != i.get(0); sumar(k, uno))
				resultado.add(0);
			for(j.add(0); j.get(0) != Integer.parseInt(toString(factor)); j = sumar(j, uno)){
				if ((factor.get(i.get(0)) * veces.get(j.get(0)) + acarreo ) <= 9) {
					resultado.add((factor.get(i.get(0)) * veces.get(j.get(0)) + acarreo ));
					acarreo = 0;
				}else{
					resultado.add((factor.get(i.get(0)) * veces.get(j.get(0)) + acarreo ) % 10);
					acarreo = ((factor.get(i.get(0)) * veces.get(j.get(0)) + acarreo ) / 10);
				}
				aux = sumar(resultado, aux);
			}
		}
		resultado = aux;
		return resultado;
	}

	public static ArrayList<Integer> multiplicacionSimple(ArrayList<Integer> factor, int veces){

		ArrayList<Integer> resultado = new ArrayList<Integer>();
		int acarreo = 0;

		for (int i = 0; i < factor.size(); i++) {
			if((factor.get(i) * veces) + acarreo <= 9){
				resultado.add((factor.get(i) * veces) + acarreo);
				acarreo = 0;
			}else{
				resultado.add(((factor.get(i) * veces) + acarreo) % 10);
				acarreo = ((factor.get(i) * veces) + acarreo) / 10;
			}

		}
		if(acarreo != 0)
			resultado.add(acarreo);

		return resultado;

	}

	public static ArrayList<Integer> restar(ArrayList<Integer> primero, ArrayList<Integer> segundo){
		int acarreo = 0;
		ArrayList<Integer> resultado = new ArrayList<Integer>();
		int g = 0;

		for (int i = 0; i < segundo.size(); i++) {
			if((int) primero.get(i) >= (int) segundo.get(i)){
				resultado.add((int) primero.get(i) - (int) segundo.get(i) - acarreo);
				acarreo = 0;
			}else if((int) primero.get(i) < ((int) segundo.get(i) + acarreo)){
				resultado.add(((int) primero.get(i) + 10) - (int) segundo.get(i) - acarreo);
				acarreo = 1;
			}
			g = i;
		}
		for (int i = g; i >= 0; i--)
			primero.remove(i);
		for (int i = 0; i < primero.size(); i++) {
			if((int) primero.get(i) < acarreo){
				resultado.add(((int) primero.get(i) + 10) - acarreo);
				acarreo = 1;
			}
			else{
				resultado.add((int) primero.get(i) - acarreo);
				acarreo = 0;
			}
		}
		return resultado;
	}

	public static ArrayList<Integer> sumar(ArrayList<Integer> primerNumero, ArrayList<Integer> segundoNumero){


		String resultadito = "";
		int contador = 0;
		int acarreo = 0;
		ArrayList<Integer> resultado= new ArrayList<Integer>();

		if (primerNumero.size() >= segundoNumero.size()) {


			for (int i = 0; i < menor(primerNumero, segundoNumero); i++) {
				if ((primerNumero.get(i) + segundoNumero.get(i) + acarreo) <= 9){
					resultado.add((primerNumero.get(i) + segundoNumero.get(i) + acarreo));
					acarreo = 0;
				}
				else {
					resultado.add((primerNumero.get(i) + segundoNumero.get(i) + acarreo) %10);
					acarreo =(primerNumero.get(i) + segundoNumero.get(i) + acarreo) /10;
				}
				contador = i;
			}
			for (int i = contador + 1; i < mayor(primerNumero, segundoNumero); i++) {
				if ((primerNumero.get(i) + acarreo) <=9){

					resultado.add((primerNumero.get(i) + acarreo));
					acarreo = 0;
				}
				else {
					resultado.add((primerNumero.get(i) + acarreo)%10);
					acarreo = ((primerNumero.get(i) + acarreo)/10);
				}

			}
			resultado.add(acarreo);
		}
		else if (primerNumero.size() < segundoNumero.size()) {
			for (int i = 0; i < menor(primerNumero, segundoNumero); i++) {
				if ((primerNumero.get(i) + segundoNumero.get(i) + acarreo) <= 9){
					resultado.add((primerNumero.get(i)  +segundoNumero.get(i) + acarreo));
					acarreo = 0;
				}
				else {
					resultado.add((primerNumero.get(i) + segundoNumero.get(i) + acarreo) % 10);
					acarreo = (primerNumero.get(i) + segundoNumero.get(i) + acarreo) /10;
				}
				contador = i;
			}
			for (int i = contador + 1; i < mayor(primerNumero, segundoNumero); i++) {
				if ((segundoNumero.get(i) + acarreo) <= 9){

					resultado.add((segundoNumero.get(i) + acarreo));
					acarreo = 0;
				}
				else {
					resultado.add((segundoNumero.get(i) + acarreo) %10);
					acarreo =((segundoNumero.get(i) + acarreo) /10);
				}

			}
			if(acarreo != 0)
				resultado.add(acarreo);
		}

		return resultado;
	}

	private static ArrayList<Integer> ingresar(ArrayList<Integer> array){
		primero = JOptionPane.showInputDialog(null, "Ingrese un n�mero");
		for (int i = primero.length() - 1; i >= 0 ; i--){
			String a = primero.charAt(i)+"";
			array.add(Integer.parseInt(a));
		}
		return array;
	}

	private static void imprimir(ArrayList msg){
		String uno = "", dos = "";
		for (int i = msg.size() - 1; i >= 0; i--)
			uno += msg.get(i);
		System.out.println(uno);
	}

	public static int mayor(ArrayList<Integer> uno, ArrayList<Integer> dos){
		if(uno.size() > dos.size())
			return uno.size();
		else
			return dos.size();
	}

	public static int menor(ArrayList<Integer> uno, ArrayList<Integer> dos){
		if(uno.size() <= dos.size())
			return uno.size();
		else
			return dos.size();
	}
}
